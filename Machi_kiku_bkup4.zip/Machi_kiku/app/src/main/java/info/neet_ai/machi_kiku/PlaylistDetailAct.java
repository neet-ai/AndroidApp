package info.neet_ai.machi_kiku;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class PlaylistDetailAct extends CommonAct {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.playlist_detail_layout);
        super.onCreate(savedInstanceState);

    }
}
