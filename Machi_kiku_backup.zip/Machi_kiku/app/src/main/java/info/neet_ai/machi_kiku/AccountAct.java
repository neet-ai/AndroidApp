package info.neet_ai.machi_kiku;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class AccountAct extends CommonAct {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.account_layout);
        super.onCreate(savedInstanceState);
    }
}
