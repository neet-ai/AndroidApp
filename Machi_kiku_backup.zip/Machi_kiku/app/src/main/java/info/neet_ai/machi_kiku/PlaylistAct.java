package info.neet_ai.machi_kiku;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class PlaylistAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.playlist_layout);
    }
}
